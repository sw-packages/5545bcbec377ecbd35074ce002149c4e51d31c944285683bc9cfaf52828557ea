#ifndef SIMDJSON_FALLBACK_H
#define SIMDJSON_FALLBACK_H

#include "simdjson/fallback/begin.h"
#include "simdjson/generic/amalgamated.h"
#include "simdjson/fallback/end.h"

#endif // SIMDJSON_FALLBACK_H
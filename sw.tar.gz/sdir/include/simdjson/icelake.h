#ifndef SIMDJSON_ICELAKE_H
#define SIMDJSON_ICELAKE_H

#include "simdjson/icelake/begin.h"
#include "simdjson/generic/amalgamated.h"
#include "simdjson/icelake/end.h"

#endif // SIMDJSON_ICELAKE_H